import torch

def gae(max_len, rewards, masks, pred_values, discount, lambda_gae):
    returns = torch.zeros(size=(max_len, 1), dtype=torch.float32)
    advants = torch.zeros(size=(max_len, 1), dtype=torch.float32)
    running_returns = 0
    previous_value = 0
    running_advants = 0

    for t in reversed(range(0, len(rewards))):
        running_returns = rewards[t][0] + \
            discount * running_returns * masks[t][0]
        running_tderror = rewards[t][0] + discount * \
            previous_value * masks[t][0] - pred_values.data[t][0]
        running_advants = running_tderror + discount * \
            lambda_gae * running_advants * masks[t][0]

        previous_value = pred_values.data[t][0]
        if t < max_len:
            returns[t][0] = running_returns
            advants[t][0] = running_advants
    # returns = (returns - returns.mean()) / returns.std()
    advants = (advants - advants.mean()) / advants.std()
    return returns, advants


class RolloutBuffer():
    def __init__(self, obs_dim, act_dim, /,
                 max_len=2048,
                 max_overrun=512,
                 act_continuous=True,
                 discount=0.98,
                 lambda_gae=0.98) -> None:
        assert (act_continuous == True)
        self.max_len = max_len
        self.obs = torch.zeros(
            (max_len+max_overrun, obs_dim), dtype=torch.float32)
        self.acts = torch.zeros(
            (max_len+max_overrun, act_dim), dtype=torch.float32)
        self.rewards = torch.zeros(
            (max_len+max_overrun, 1), dtype=torch.float32)
        self.pred_values = torch.zeros(
            (max_len+max_overrun, 1), dtype=torch.float32)
        self.target_logprobs = torch.zeros(
            (max_len+max_overrun, 1), dtype=torch.float32)
        self.masks = torch.zeros((max_len+max_overrun, 1), dtype=torch.int8)
        self.n = 0
        self.finished = False
        self.discount = discount
        self.lambda_gae = lambda_gae

    def append(self, obs, act, reward, pred_value, target_logprob, terminated):
        assert (not self.finished)
        self.obs[self.n, :] = obs
        self.acts[self.n, :] = act
        self.rewards[self.n, 0] = reward
        self.pred_values[self.n, 0] = pred_value
        self.target_logprobs[self.n, 0] = target_logprob
        self.masks[self.n, 0] = not terminated
        self.n += 1

    def convert_to_gae(self):
        returns, advants = gae(
                self.max_len,
                self.rewards,
                self.masks,
                self.pred_values,
                self.discount,
                self.lambda_gae)
        self.returns = returns
        self.advants = advants

        self.rewards = None
        self.masks = None
        self.pred_values = None
        self.finished = True