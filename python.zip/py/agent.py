from typing import List, Tuple, Type
import torch
from models.pymodel import PyActorCritic
from py.optimizations.observation_normalizer import ObservationNormalizer
from py.rollout_buffer import RolloutBuffer
from gym import Env
import logging

class Agent():
    def __init__(
        self,
        model_class: Type[PyActorCritic],
        obs_dim,
        act_dim,
        /,
        lr_actor=1e-4,
        lr_critic=1e-3,
        hidden_width=64,
        act_continuous=True
    ) -> None:
        self.act_continuous = act_continuous
        self.distribution = (
            torch.distributions.Normal if self.act_continuous
            else torch.distributions.Categorical)
        self.critic_loss_func = torch.nn.MSELoss()

        self.ac = model_class(
            obs_dim,
            act_dim,
            lr_actor=lr_actor,
            lr_critic=lr_critic,
            hidden_width=hidden_width,
            act_continuous=act_continuous
        )

        self._obs_dim = obs_dim
        self._act_dim = act_dim

        self.obs_normalizer = ObservationNormalizer((obs_dim, ))

        logging.info(f"Agent initialized with obs_dim={obs_dim}, act_dim={act_dim}")

    @property
    def lr_critic(self):
        return self.ac.lr_critic

    @lr_critic.setter
    def lr_critic(self, value):
        self.ac.lr_critic = value

    @property
    def lr_actor(self):
        return self.ac.lr_actor

    @lr_actor.setter
    def lr_actor(self, value):
        self.ac.lr_actor = value

    def save(self, prefix):
        self.obs_normalizer.save(f'{prefix}.obsnorm.npz')
        self.ac.save(f"{prefix}.model.dat")

    def load(self, prefix):
        self.obs_normalizer.load(f'{prefix}.obsnorm.npz')
        self.ac.load(f"{prefix}.model.dat")

    def predict(self, obs, update_normalizer):
        value, pi = self.ac.forward(obs)
        if self.act_continuous:
            mu, rho = pi
            sigma = torch.exp(rho)
            distrib = self.distribution(mu, sigma)
            return value, distrib
        else:
            raise NotImplementedError()

    def train_batch(self, b_obs, b_acts, b_target_logprobs, b_returns, b_advantages):
        raise NotImplementedError()

    @property
    def obs_dim(self):
        return self._obs_dim

    @property
    def act_dim(self):
        return self._act_dim

    def generate_rb(self, env: Env, seed=None, stop_when_terminated=False, max_steps=2048, max_overrun=512, discount=0.99, lambda_gae=0.9, training=False):
        rb = RolloutBuffer(
            self.obs_dim,
            self.act_dim,
            max_len=max_steps,
            max_overrun=max_overrun,
            act_continuous=self.act_continuous,
            discount=discount,
            lambda_gae=lambda_gae
        )

        self.obs_normalizer.update_normalizer=training

        obs, _ = env.reset(seed=seed)
        obs = self.obs_normalizer(obs)

        rewards: List[Tuple[int, float]] = []
        episode_reward = 0
        while rb.n < max_steps + max_overrun:
            value, distrib = self.predict(
                torch.tensor(obs.reshape((1, -1)), dtype=torch.float32),
                update_normalizer=True)
            act = distrib.sample()
            logprob = distrib.log_prob(act).detach()
            next_obs, reward, terminated, _, __ = env.step(act[0].detach().numpy())
            next_obs = self.obs_normalizer(next_obs)
            episode_reward += reward
            rb.append(torch.tensor(obs), act, reward, value, logprob.sum(1, keepdim=True), terminated)
            if terminated:
                # Break before increase finished_episodes because it will be
                #  increased after the while loop
                if stop_when_terminated or rb.n >= max_steps:
                    break
                rewards.append((rb.n, episode_reward))
                episode_reward = 0
                obs, info = env.reset(seed=seed)
                obs = self.obs_normalizer(obs)
            else:
                obs = next_obs

        rewards.append((rb.n, episode_reward))

        return rb, rewards


class PPOAgent(Agent):
    def __init__(
        self,
        model_class: Type[PyActorCritic],
        obs_dim,
        act_dim,
        /,
        lr_actor=1e-4,
        lr_critic=1e-3,
        hidden_width=64,
        act_continuous=True,
        epsilon=0.2
    ) -> None:
        super().__init__(model_class, obs_dim, act_dim, lr_actor,
                         lr_critic, hidden_width, act_continuous)
        self.epsilon = epsilon

    def train_batch(self, b_obs, b_acts, b_target_logprobs, b_returns, b_advantages):
        values, pi = self.ac.forward(b_obs.detach())
        mu, rho = pi
        sigma = torch.exp(rho)
        distribs = self.distribution(mu, sigma)

        critic_loss = self.critic_loss_func(values, b_returns.detach())

        logprobs = distribs.log_prob(b_acts.detach()).sum(dim=-1, keepdim=True)

        ratios = torch.exp(logprobs - b_target_logprobs.detach())

        surrogate_loss = b_advantages.detach() * ratios
        clipped_loss = (
            torch.clamp(ratios, 1 - self.epsilon, 1 + self.epsilon)
            * b_advantages.detach()
        )
        ppo_loss = -torch.min(surrogate_loss, clipped_loss).mean()

        entropy_loss = -0.01 * distribs.entropy().sum(dim=-1).mean()

        loss = critic_loss + ppo_loss + entropy_loss

        self.ac.optim_zero_grad()
        loss.backward()
        if mu.is_leaf:
            self.ac.backward(values.grad, mu.grad, rho.grad)
        self.ac.optim_step()

        return critic_loss.item(), ppo_loss.item(), entropy_loss.item()